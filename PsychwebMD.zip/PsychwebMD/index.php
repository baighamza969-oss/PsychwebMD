<?php
$pageTitle = "PsychwebMD - Mental Healthcare Anywhere, Anytime";
include 'includes/header.php';
?>

<?php include 'sections/hero.php'; ?>
<?php include 'sections/services.php'; ?>
<?php include 'sections/how-it-works.php'; ?>
<?php include 'sections/why-psychwebmd.php'; ?>
<?php include 'sections/faqs.php'; ?>
<?php include 'sections/newsletter.php'; ?>

<?php include 'includes/footer.php'; ?>


